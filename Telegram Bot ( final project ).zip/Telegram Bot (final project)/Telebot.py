# U.S. STATE INFORMATION BOT
import telebot
import requests
#Importing api key from openweather.org
from api import API_KEY
#Importing token from Telegram (BotFather)
from api import TELE_TOKEN

bot = telebot.TeleBot(TELE_TOKEN)

# Making start function

@bot.message_handler(commands = ['start'])
def start(text):
    name = text.from_user.first_name
    hello = 'Hello '+ name + ' :)'
    bot.send_message(text.chat.id,hello)

# Making main function
#(Searching states of U.S. from name of state in user input and output basic state information with state flag picture)
#Outputing state weather
@bot.message_handler()
def get_user_text(text):
        states = ['Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut','Delaware','Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania','Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont','Virginia','Washington','West Virginia','Wisconsin','Wyoming']
        params = {'q':text.text,"appid" : API_KEY,'units':'metric'}
        response = requests.get('https://api.openweathermap.org/data/2.5/weather',params = params)
        weather = response.json()
        if text.text in states:
            state = open(text.text + '.txt','r')
            photo_state = open(text.text + '.jpg','rb')
            bot.send_message(text.chat.id,state)
            bot.send_photo(text.chat.id,photo_state)
            main = weather['weather'][0]['main']
            temp = weather['main']['temp']
            weather_state = 'Weather of ' + text.text + ' is : ' + str(main) + ' Temperature is : ' + str(temp)
            bot.send_message(text.chat.id,weather_state)
            if main == 'Clear':
                clear = open('clear.gif','rb')
                bot.send_photo(text.chat.id,clear)
            elif main == 'Clouds':
                clouds = open('clouds.gif','rb')
                bot.send_photo(text.chat.id,clouds)
                
            
        else:
            name = text.from_user.first_name
            no = 'There is no state in the USA with the name you specified ' + name + ' (Or you wrote the name of the state with a small letter :)'
            bot.send_message(text.chat.id,no)
      
        
            
            
            
        
            
        
    



    

bot.polling(none_stop = True)
    
